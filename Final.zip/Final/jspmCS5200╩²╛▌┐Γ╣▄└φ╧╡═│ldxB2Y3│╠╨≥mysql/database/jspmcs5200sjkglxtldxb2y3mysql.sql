/*
Navicat MySQL Data Transfer

Source Server         : localhost_3306
Source Server Version : 50160
Source Host           : localhost:3306
Source Database       : jspmcs5200sjkglxtldxb2y3mysql

Target Server Type    : MYSQL
Target Server Version : 50160
File Encoding         : 65001

Date: 2018-04-17 02:25:52
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for `allusers`
-- ----------------------------
DROP TABLE IF EXISTS `allusers`;
CREATE TABLE `allusers` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(50) DEFAULT NULL,
  `pwd` varchar(50) DEFAULT NULL,
  `cx` varchar(50) DEFAULT '超级管理员',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of allusers
-- ----------------------------
INSERT INTO `allusers` VALUES ('1', 'hsg', 'hsg', '超级管理员', '2018-04-15 02:47:20');
INSERT INTO `allusers` VALUES ('2', 'ldx', 'ldx', '普通管理员', '2018-04-16 20:40:31');

-- ----------------------------
-- Table structure for `banjixinxi`
-- ----------------------------
DROP TABLE IF EXISTS `banjixinxi`;
CREATE TABLE `banjixinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `banji` varchar(50) DEFAULT NULL,
  `banjijianjie` varchar(255) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of banjixinxi
-- ----------------------------
INSERT INTO `banjixinxi` VALUES ('1', '经济管理2017', '经济管理2017经济管理2017', '', '2018-04-15 03:20:18');
INSERT INTO `banjixinxi` VALUES ('2', '2017计算机班', '2017计算机班2017计算机班', '', '2018-04-16 20:05:40');

-- ----------------------------
-- Table structure for `chengjixinxi`
-- ----------------------------
DROP TABLE IF EXISTS `chengjixinxi`;
CREATE TABLE `chengjixinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `xuehao` varchar(50) DEFAULT NULL,
  `xueshengxingming` varchar(50) DEFAULT NULL,
  `nianfen` varchar(50) DEFAULT NULL,
  `xueqi` varchar(50) DEFAULT NULL,
  `kechengmingcheng` varchar(50) DEFAULT NULL,
  `chengji` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of chengjixinxi
-- ----------------------------
INSERT INTO `chengjixinxi` VALUES ('1', '222', '李四', '2018', '上半学期', '经济学', '98', '', '2018-04-16 20:45:17');
INSERT INTO `chengjixinxi` VALUES ('2', '111', '张三', '2018', '上半学期', '计算机应用2018', '90', '', '2018-04-16 20:45:39');

-- ----------------------------
-- Table structure for `dx`
-- ----------------------------
DROP TABLE IF EXISTS `dx`;
CREATE TABLE `dx` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `leibie` varchar(50) DEFAULT NULL,
  `content` longtext,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of dx
-- ----------------------------
INSERT INTO `dx` VALUES ('1', '系统公告', '<P>&nbsp;&nbsp;&nbsp; 欢迎大家登陆我站，我站主要是为广大朋友精心制作的一个系统，希望大家能够在我站获得一个好心情，谢谢！</P>\r\n<P>&nbsp;&nbsp;&nbsp; 自强不息，海纳百川，努力学习！</P>');
INSERT INTO `dx` VALUES ('2', '系统简介', 'CS5200数据库管理系统系统简介');

-- ----------------------------
-- Table structure for `fudaoyuanxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `fudaoyuanxinxi`;
CREATE TABLE `fudaoyuanxinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fudaoyuanbianhao` varchar(50) DEFAULT NULL,
  `mima` varchar(50) DEFAULT NULL,
  `fudaoyuanxingming` varchar(50) DEFAULT NULL,
  `jianjie` varchar(255) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `zhicheng` varchar(50) DEFAULT NULL,
  `lianxidianhua` varchar(50) DEFAULT NULL,
  `youxiang` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `issh` varchar(2) DEFAULT '否',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of fudaoyuanxinxi
-- ----------------------------
INSERT INTO `fudaoyuanxinxi` VALUES ('1', 'fff', 'fff', '李六', '简介简介简介简介', '女', '教授', '13587444114', '22265622@qq.com', '', '是', '2018-04-16 15:23:40');
INSERT INTO `fudaoyuanxinxi` VALUES ('2', 'ffff', 'ffff', '李六六', '简介简介', '男', '教授', '13355555555', '22222@qq.com', '', '是', '2018-04-16 20:40:07');

-- ----------------------------
-- Table structure for `jiaoshixinxi`
-- ----------------------------
DROP TABLE IF EXISTS `jiaoshixinxi`;
CREATE TABLE `jiaoshixinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `jiaoshibianhao` varchar(50) DEFAULT NULL,
  `mima` varchar(50) DEFAULT NULL,
  `jiaoshixingming` varchar(50) DEFAULT NULL,
  `jianjie` varchar(255) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `zhicheng` varchar(50) DEFAULT NULL,
  `lianxidianhua` varchar(50) DEFAULT NULL,
  `youxiang` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `issh` varchar(2) DEFAULT '否',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of jiaoshixinxi
-- ----------------------------
INSERT INTO `jiaoshixinxi` VALUES ('1', 'aaa', 'aaa', '李教师', '简介', '男', '教授', '1558744411', '42424@qq.com', '', '是', '2018-04-15 03:21:57');
INSERT INTO `jiaoshixinxi` VALUES ('2', 'jjj', 'jjj', '王教师', '简介简介简介简介', '男', '教授', '1558744411', '2222352@qq.com', '', '是', '2018-04-16 20:38:50');

-- ----------------------------
-- Table structure for `kechengxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `kechengxinxi`;
CREATE TABLE `kechengxinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `kechengbianhao` varchar(50) DEFAULT NULL,
  `kechengmingcheng` varchar(50) DEFAULT NULL,
  `kechengjianjie` varchar(255) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of kechengxinxi
-- ----------------------------
INSERT INTO `kechengxinxi` VALUES ('1', '001', '计算机应用2018', '计算机应用2018计算机应用2018', '计算机应用2018计算机应用2018', '2018-04-16 16:34:52');
INSERT INTO `kechengxinxi` VALUES ('2', '002', '经济学', '经济学经济学', '', '2018-04-16 20:41:49');

-- ----------------------------
-- Table structure for `pinglun`
-- ----------------------------
DROP TABLE IF EXISTS `pinglun`;
CREATE TABLE `pinglun` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `xinwenID` varchar(50) DEFAULT NULL,
  `pinglunneirong` varchar(255) DEFAULT NULL,
  `pinglunren` varchar(50) DEFAULT NULL,
  `pingfen` varchar(50) DEFAULT NULL,
  `biao` varchar(50) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of pinglun
-- ----------------------------
INSERT INTO `pinglun` VALUES ('1', '2', '好', '111', '1', 'zhujiaoxinxi', '2018-04-16 20:43:19');
INSERT INTO `pinglun` VALUES ('3', '2', '好好好', '111', '1', 'fudaoyuanxinxi', '2018-04-16 20:43:44');
INSERT INTO `pinglun` VALUES ('4', '2', '好好好好', '111', '1', 'kechengxinxi', '2018-04-16 20:43:55');
INSERT INTO `pinglun` VALUES ('5', '2', '好好好好好', '111', '1', 'xueyuanxinxi', '2018-04-16 20:44:13');
INSERT INTO `pinglun` VALUES ('6', '1', 'vvvvvvvvvvvvvvv', '222', '1', 'zhujiaoxinxi', '2018-04-16 20:53:37');
INSERT INTO `pinglun` VALUES ('7', '1', 'cccccccccccc', '222', '1', 'jiaoshixinxi', '2018-04-16 20:53:55');

-- ----------------------------
-- Table structure for `xinwentongzhi`
-- ----------------------------
DROP TABLE IF EXISTS `xinwentongzhi`;
CREATE TABLE `xinwentongzhi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `biaoti` varchar(255) DEFAULT NULL,
  `leibie` varchar(50) DEFAULT NULL,
  `neirong` longtext,
  `tianjiaren` varchar(50) DEFAULT NULL,
  `shouyetupian` varchar(50) DEFAULT NULL,
  `dianjilv` int(11) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xinwentongzhi
-- ----------------------------
INSERT INTO `xinwentongzhi` VALUES ('1', 'dfsdf', '变幻图', '', 'hsg', 'upload/1523881897408.jpg', '1', '2018-04-16 20:31:39');
INSERT INTO `xinwentongzhi` VALUES ('2', 'dgasdg', '变幻图', '', 'hsg', 'upload/1523881906174.jpg', '1', '2018-04-16 20:31:47');
INSERT INTO `xinwentongzhi` VALUES ('3', 'gasg', '变幻图', '', 'hsg', 'upload/1523881986995.jpg', '1', '2018-04-16 20:33:08');
INSERT INTO `xinwentongzhi` VALUES ('4', 'dgag', '变幻图', '', 'hsg', 'upload/1523882055982.jpg', '1', '2018-04-16 20:34:19');
INSERT INTO `xinwentongzhi` VALUES ('5', 'dfa', '变幻图', '', 'hsg', 'upload/1523882077210.jpg', '1', '2018-04-16 20:34:38');

-- ----------------------------
-- Table structure for `xinxijiaoliu`
-- ----------------------------
DROP TABLE IF EXISTS `xinxijiaoliu`;
CREATE TABLE `xinxijiaoliu` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `fudaoyuanxingming` varchar(50) DEFAULT NULL,
  `fudaoyuanbianhao` varchar(50) DEFAULT NULL,
  `xinxineirong` varchar(255) DEFAULT NULL,
  `huifu` varchar(255) DEFAULT NULL,
  `fasongren` varchar(50) DEFAULT NULL,
  `fasongrenxingming` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xinxijiaoliu
-- ----------------------------
INSERT INTO `xinxijiaoliu` VALUES ('1', '李六', 'fff', '你好', 'yyy', '111', '张三', '', '2018-04-16 19:17:33');
INSERT INTO `xinxijiaoliu` VALUES ('2', '李六六', 'ffff', '好发b', '', 'zzzz', 'xxx', '', '2018-04-16 20:46:04');
INSERT INTO `xinxijiaoliu` VALUES ('3', '李六', 'fff', 'sasdfsdga', '好地', 'aaa', '李', '', '2018-04-16 20:49:34');
INSERT INTO `xinxijiaoliu` VALUES ('4', '李六六', 'ffff', '你好xxxxxxxxxx', 'ccccccccccccc', '111', '张三', '', '2018-04-16 20:52:01');

-- ----------------------------
-- Table structure for `xuankexinxi`
-- ----------------------------
DROP TABLE IF EXISTS `xuankexinxi`;
CREATE TABLE `xuankexinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `kechengmingcheng` varchar(50) DEFAULT NULL,
  `kechengjianjie` varchar(50) DEFAULT NULL,
  `xuehao` varchar(50) DEFAULT NULL,
  `xueshengxingming` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xuankexinxi
-- ----------------------------
INSERT INTO `xuankexinxi` VALUES ('1', '计算机应用2018', '计算机应用2018计算机应用2018', '111', '张三', 'dfsadg', '2018-04-16 18:28:54');
INSERT INTO `xuankexinxi` VALUES ('2', '经济学', '经济学经济学', '222', '李四', '', '2018-04-16 20:51:19');

-- ----------------------------
-- Table structure for `xueshenganpai`
-- ----------------------------
DROP TABLE IF EXISTS `xueshenganpai`;
CREATE TABLE `xueshenganpai` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `xuehao` varchar(50) DEFAULT NULL,
  `xueshengxingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `xueyuan` varchar(50) DEFAULT NULL,
  `banji` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xueshenganpai
-- ----------------------------
INSERT INTO `xueshenganpai` VALUES ('1', '111', '张三', '男', '经管学院', '2017计算机班', '', '2018-04-16 20:06:05');
INSERT INTO `xueshenganpai` VALUES ('2', '222', '李四', '男', '经管学院', '经济管理2017', '', '2018-04-16 20:50:28');

-- ----------------------------
-- Table structure for `xueshengxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `xueshengxinxi`;
CREATE TABLE `xueshengxinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `xuehao` varchar(50) DEFAULT NULL,
  `mima` varchar(50) DEFAULT NULL,
  `xueshengxingming` varchar(50) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `xueyuan` varchar(50) DEFAULT NULL,
  `banji` varchar(50) DEFAULT NULL,
  `shenfenzhenghao` varchar(50) DEFAULT NULL,
  `lianxidianhua` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `issh` varchar(2) DEFAULT '否',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xueshengxinxi
-- ----------------------------
INSERT INTO `xueshengxinxi` VALUES ('1', '111', '111', '张三', '男', '经管学院', '2017计算机班', '330327198802110211', '12345678', '', '是', '2018-04-15 03:20:42');
INSERT INTO `xueshengxinxi` VALUES ('2', '222', '222', '李四', '男', '经管学院', '2017计算机班', '330327198802110211', '1558744411', '', '是', '2018-04-16 20:38:28');

-- ----------------------------
-- Table structure for `xueyuanxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `xueyuanxinxi`;
CREATE TABLE `xueyuanxinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `xueyuan` varchar(50) DEFAULT NULL,
  `jianjie` varchar(255) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of xueyuanxinxi
-- ----------------------------
INSERT INTO `xueyuanxinxi` VALUES ('1', '经管学院', '经管学院经管学院经管学院', '', '2018-04-15 03:20:01');
INSERT INTO `xueyuanxinxi` VALUES ('2', '计算机学院', '计算机学院计算机学院', '', '2018-04-16 20:40:46');

-- ----------------------------
-- Table structure for `zhujiaoxinxi`
-- ----------------------------
DROP TABLE IF EXISTS `zhujiaoxinxi`;
CREATE TABLE `zhujiaoxinxi` (
  `ID` int(11) NOT NULL AUTO_INCREMENT,
  `zhujiaobianhao` varchar(50) DEFAULT NULL,
  `mima` varchar(50) DEFAULT NULL,
  `zhujiaoxingming` varchar(50) DEFAULT NULL,
  `jianjie` varchar(255) DEFAULT NULL,
  `xingbie` varchar(50) DEFAULT NULL,
  `zhicheng` varchar(50) DEFAULT NULL,
  `lianxidianhua` varchar(50) DEFAULT NULL,
  `youxiang` varchar(50) DEFAULT NULL,
  `beizhu` varchar(255) DEFAULT NULL,
  `issh` varchar(2) DEFAULT '否',
  `addtime` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
  PRIMARY KEY (`ID`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of zhujiaoxinxi
-- ----------------------------
INSERT INTO `zhujiaoxinxi` VALUES ('1', 'zzz', 'zzz', '王五', '简介简介简介简介', '男', '教授', '13566666666', '22265622@qq.com', '', '是', '2018-04-16 15:22:58');
INSERT INTO `zhujiaoxinxi` VALUES ('2', 'zzzz', 'zzzz', '李王', '简介简介简', '男', '教授', '13566666666', '22265622@qq.com', '', '是', '2018-04-16 20:39:32');
